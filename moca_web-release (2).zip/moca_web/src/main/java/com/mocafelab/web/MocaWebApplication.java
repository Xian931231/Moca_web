package com.mocafelab.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MocaWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(MocaWebApplication.class, args);
	}

}
